// File: script.js (Phiên bản "Cách 1")

// Bước 1: Import thư viện của Google
import { GoogleGenerativeAI } from "https://cdn.jsdelivr.net/npm/@google/generative-ai/+esm";

// #########################################################
// DÁN API KEY CỦA BẠN VÀO ĐÂY
const API_KEY = "AIzaSyCV65xfmSF78nhmaPies6HmhdpIQxJtpBg"; 
// #########################################################

// PHẦN "TRAINING" (Dán mô tả museBOT của bạn vào đây)
const SYSTEM_PROMPT = `
Bạn là museBOT. Bạn là một chuyên gia lịch sử Đà Nẵng, phục vụ cho bảo tàng
Đà Nẵng, chuyên tim kiểm thông tin từ các tài liệu nội bộ...
(Dán toàn bộ mô tả Kỹ năng và Ràng buộc của bạn vào đây)
...
- Chỉ trả lời các câu hỏi liên quan đến lịch sử việt Nam.
`;

// Bước 2: Khởi tạo mô hình
const genAI = new GoogleGenerativeAI(API_KEY);
const model = genAI.getGenerativeModel({
    model: "gemini-1.5-flash",
    systemInstruction: SYSTEM_PROMPT, // "Training" ở đây
});

// Bước 3: Lấy các phần tử trên trang web
const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");
const sendButton = document.getElementById("send-button");
const loadingIndicator = document.getElementById("loading");

// Bước 4: Xử lý khi người dùng nhấn nút "Gửi"
async function handleUserInput() {
    const prompt = userInput.value.trim();
    if (!prompt) return; 

    addMessageToChatbox(prompt, "user-message");
    userInput.value = "";
    loadingIndicator.classList.remove("hidden");

    try {
        // Gọi API Gemini
        const result = await model.generateContent(prompt); 
        const response = await result.response;
        const text = response.text();

        // Hiển thị câu trả lời của Bot
        addMessageToChatbox(text, "bot-message");

    } catch (error) {
        console.error("Lỗi gọi API:", error);
        addMessageToChatbox("Xin lỗi, có lỗi xảy ra. Vui lòng kiểm tra Console (F12).", "bot-message");
    } finally {
        loadingIndicator.classList.add("hidden");
    }
}

// Hàm phụ để thêm tin nhắn vào khung chat
function addMessageToChatbox(message, messageClass) {
    const p = document.createElement("p");
    p.textContent = message;
    p.className = messageClass;
    chatBox.appendChild(p);
    chatBox.scrollTop = chatBox.scrollHeight;
}

// Thêm sự kiện cho nút Gửi
sendButton.addEventListener("click", handleUserInput);

// Cho phép nhấn Enter để gửi
userInput.addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
        handleUserInput();
    }
});